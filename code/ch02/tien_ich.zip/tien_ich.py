# -*- coding: utf-8 -*-
"""Mo-dun tien ich dung chung cho cac executor (Doan ma 2.5)."""
import unicodedata


def chuan_hoa_ten(s):
    """Bo dau tieng Viet, gom khoang trang, viet hoa chu cai dau."""
    if s is None:
        return None
    s = unicodedata.normalize("NFD", s)
    s = "".join(ch for ch in s if unicodedata.category(ch) != "Mn").replace("đ", "d").replace("Đ", "D")
    return " ".join(s.split()).title()
